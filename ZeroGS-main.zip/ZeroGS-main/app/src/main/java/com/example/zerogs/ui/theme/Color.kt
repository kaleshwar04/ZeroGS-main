package com.example.zerogs.ui.theme

import androidx.compose.ui.graphics.Color

val Blue300 = Color(0xFFD8EDFD)
val Green100 = Color(0xFFCCE8DB)
val Purple200 = Color(0xFFBEB4D6)
val Purple500 = Color(0xFFFADAE2)
val Purple700 = Color(0xFFCC97C1)
val Grey90 = Color(0xFFD0D0D0)
val Grey10 = Color(0xFFEDF0F7)